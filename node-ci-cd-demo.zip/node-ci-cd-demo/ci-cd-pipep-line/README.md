# Node.js CI/CD Demo
## How to run Locally
1. Clone the repository:
   ```bash
   git clone <your-repo-url>